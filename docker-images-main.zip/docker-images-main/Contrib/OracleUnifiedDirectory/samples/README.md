# Oracle Unified Directory Samples

## 122140-simple-ldap

Provides a Docker Compose example file for Oracle Unified Directory 12.2.1.4.0