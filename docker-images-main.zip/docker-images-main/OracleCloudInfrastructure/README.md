# Oracle Cloud Infrastructure Container Images

The following Oracle Cloud Infrastructure tools are available as container images:

* [OCI Command Line Interface](oci-cli/)
* [OCI Provider for Terraform](terraform-oci/)
